package cmd

func init() {
	saleCmd.AddCommand(newCRUDSubCmd("return", "/erp/sale-return", "销售退货"))
}
