package cmd

import "github.com/spf13/cobra"

var productCmd = &cobra.Command{
	Use:   "product",
	Short: "产品管理",
	Long:  "产品模块操作：产品、分类、单位、指标。",
}

func init() {
	rootCmd.AddCommand(productCmd)
}
