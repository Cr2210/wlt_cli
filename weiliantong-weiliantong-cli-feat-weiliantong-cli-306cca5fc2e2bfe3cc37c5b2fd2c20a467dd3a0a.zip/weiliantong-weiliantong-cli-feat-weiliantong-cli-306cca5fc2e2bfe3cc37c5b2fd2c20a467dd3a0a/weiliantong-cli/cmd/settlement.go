package cmd

import "github.com/spf13/cobra"

var settlementCmd = &cobra.Command{
	Use:   "settlement",
	Short: "结算管理",
	Long:  "结算模块操作：结算单CRUD、取消结算运单。",
}

func init() {
	rootCmd.AddCommand(settlementCmd)
}
