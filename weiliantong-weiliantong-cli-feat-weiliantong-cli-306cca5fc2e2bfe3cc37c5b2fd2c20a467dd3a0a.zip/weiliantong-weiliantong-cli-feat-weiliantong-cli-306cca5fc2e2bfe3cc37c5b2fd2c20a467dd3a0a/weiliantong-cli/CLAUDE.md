# CLAUDE.md — weiliantong-cli

## 项目概述

weiliantong-cli（`wlt`）是维链通 ERP 系统的命令行工具，AI Agent 原生设计。

## 技术栈

- Go 1.26+ / Cobra CLI 框架
- 关键依赖：`github.com/spf13/cobra`, `github.com/tidwall/gjson`, `gopkg.in/yaml.v3`, `github.com/charmbracelet/huh`

## 开发命令

```bash
make build          # 构建 wlt 二进制
make test           # 运行所有测试
make install        # 安装到 /usr/local/bin
make clean          # 清理构建产物
```

## 项目结构

```
cmd/                # Cobra 命令层（所有文件在同一个 package cmd）
├── root.go         # 根命令 + 全局 helpers（ensureClient, outputJSON 等）
├── auth*.go        # 认证命令
├── config*.go      # 配置命令
├── api.go          # 通用 API 调用
├── version.go      # 版本信息
└── stock*.go       # 库存模块命令（共享 CRUD 辅助函数）
internal/
├── apierr/         # 结构化错误类型
├── auth/           # 认证逻辑（使用原生 net/http，不依赖 client）
├── build/          # 版本信息（ldflags 注入）
├── client/         # HTTP 客户端（认证头 + 多租户 + 重试 + CommonResult 解析）
├── config/         # 配置文件管理（~/.wlt/config.yaml）
└── output/         # JSON 输出格式化（stdout/stderr 分离）
skills/             # AI Agent Skills Markdown
```

## 架构约定

- **包依赖无循环**：auth 使用原生 net/http，不依赖 client 包
- **命令注册**：所有命令在 `cmd` 包内，使用 `init()` 注册到父命令
- **输出协议**：stdout 数据 JSON / stderr 错误 JSON / 退出码 0-6
- **CRUD 模式**：`stock.go` 中的 `newCRUDSubCmd()` 为 in/out/move/check 提供通用 CRUD 子命令

## 后端 API 约定

- 基础路径：`{base_url}{api_prefix}`（如 `https://erpsit.api.w-lian.com/admin-api`）
- 统一响应：`CommonResult<T>` — `{ "code": 0, "data": T, "msg": "" }`
- 认证头：`Authorization: Bearer {token}`
- 多租户头：`tenant-id`, `visit-tenant-id`
- 分页：`GET /page?pageNo=1&pageSize=20` → `{ "list": [...], "total": N }`
- 删除：`DELETE /delete?ids=1,2,3`
