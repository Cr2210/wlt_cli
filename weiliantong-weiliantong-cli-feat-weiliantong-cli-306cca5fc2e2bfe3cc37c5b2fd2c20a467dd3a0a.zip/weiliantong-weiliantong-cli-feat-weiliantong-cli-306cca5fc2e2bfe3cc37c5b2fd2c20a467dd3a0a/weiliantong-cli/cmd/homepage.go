package cmd

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/cobra"

	"github.com/weiliantong/cli/internal/output"
)

var inventoryFlags = []FlagSpec{
	{Name: "product-id", Usage: "产品 ID"},
	{Name: "warehouse-id", Usage: "仓库 ID"},
}

func init() {
	homepageCmd := &cobra.Command{
		Use:   "homepage",
		Short: "首页数据总览",
		Long:  "首页仪表盘数据：业务概览、库存分析、库存积压、产品排行。",
	}

	// dashboard1 - 无参数
	homepageCmd.AddCommand(newHomepageNoParamCmd("dashboard1", "首页仪表盘（基础统计）"))

	// dashboard2 - 带时间范围
	homepageCmd.AddCommand(newStatsGetCmd("dashboard2", "/erp/homepage", "业务概览", nil))

	// dashboard6 / inventory-backlog / product-ranking - 带库存筛选
	homepageCmd.AddCommand(newStatsGetCmd("dashboard6", "/erp/homepage", "库存分析", inventoryFlags))
	homepageCmd.AddCommand(newStatsGetCmd("inventory-backlog", "/erp/homepage", "库存积压", inventoryFlags))
	homepageCmd.AddCommand(newStatsGetCmd("product-ranking", "/erp/homepage", "产品排行", inventoryFlags))

	rootCmd.AddCommand(homepageCmd)
}

func newHomepageNoParamCmd(name, label string) *cobra.Command {
	c := &cobra.Command{
		Use:   name,
		Short: label,
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Get(context.Background(), "/erp/homepage/"+name, nil)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	return c
}
