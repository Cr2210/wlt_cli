# wlt-stock — 库存操作

## 前置条件

- 已通过 `wlt auth login` 登录
- 已确认 `wlt auth status` 状态有效（status 为 "logged_in"）

## 命令参考

### 仓库管理

| 命令 | 说明 | 关键参数 |
|------|------|---------|
| `wlt stock warehouse list` | 分页查询仓库 | `--page-no`, `--page-size`, `--name`, `--status` |
| `wlt stock warehouse get --id <N>` | 获取仓库详情 | `--id` |
| `wlt stock warehouse simple-list` | 获取仓库精简列表 | 无 |
| `wlt stock warehouse create --data '<json>'` | 创建仓库 | `--data` JSON |
| `wlt stock warehouse update --data '<json>'` | 更新仓库 | `--data` JSON |
| `wlt stock warehouse delete --ids <id1,id2>` | 删除仓库 | `--ids` 逗号分隔 |
| `wlt stock warehouse update-status --data '<json>'` | 更新仓库状态 | `--data` JSON（含 id 和 status） |

### 库存查询

| 命令 | 说明 | 关键参数 |
|------|------|---------|
| `wlt stock query get` | 获取单个库存 | `--id` 或 `--product-id` + `--warehouse-id` |
| `wlt stock query list` | 分页查询库存 | `--page-no`, `--page-size`, `--warehouse-id`, `--product-name` |
| `wlt stock query count` | 统计库存数量 | `--warehouse-id`（可选）, `--metric-name`（可选） |
| `wlt stock query batch-detail` | 获取批次明细 | `--page-no`, `--page-size`, `--product-id`, `--warehouse-id` |

### 入库单

| 命令 | 说明 | 关键参数 |
|------|------|---------|
| `wlt stock in list` | 分页查询入库单 | `--page-no`, `--page-size`, `--no`, `--status` |
| `wlt stock in get --id <N>` | 获取入库单详情 | `--id` |
| `wlt stock in create --data '<json>'` | 创建入库单 | `--data` JSON |
| `wlt stock in update --data '<json>'` | 更新入库单 | `--data` JSON |
| `wlt stock in delete --ids <id1,id2>` | 删除入库单 | `--ids` |
| `wlt stock in update-status --data '<json>'` | 更新入库单状态 | `--data` JSON（含 id 和 status） |

### 出库单

与入库单结构相同，将 `in` 替换为 `out`：

`wlt stock out list`, `wlt stock out get`, `wlt stock out create`, `wlt stock out update`, `wlt stock out delete`, `wlt stock out update-status`

### 调拨单

与入库单结构相同，将 `in` 替换为 `move`：

`wlt stock move list`, `wlt stock move get`, `wlt stock move create`, `wlt stock move update`, `wlt stock move delete`, `wlt stock move update-status`

### 盘点单

与入库单结构相同，将 `in` 替换为 `check`：

`wlt stock check list`, `wlt stock check get`, `wlt stock check create`, `wlt stock check update`, `wlt stock check delete`, `wlt stock check update-status`

### 库存明细

| 命令 | 说明 | 关键参数 |
|------|------|---------|
| `wlt stock record list` | 分页查询明细 | `--page-no`, `--page-size`, `--product-id`, `--warehouse-id` |
| `wlt stock record get --id <N>` | 获取明细详情 | `--id` |
| `wlt stock record count` | 获取明细总数量 | 无 |

## 通用 API 调用

对于未提供快捷命令的端点，使用通用 API 调用：

```bash
# GET 请求
wlt api GET /erp/warehouse/simple-list

# POST 请求
wlt api POST /erp/warehouse/create --data '{"name":"新仓库"}'

# 带查询参数
wlt api GET /erp/stock/page --params '{"pageNo":1,"pageSize":20}'

# 调试（不发送请求）
wlt api GET /erp/warehouse/page --dry-run
```

## 常见工作流

### 1. 查询某仓库库存

```bash
# 获取仓库列表，找到目标仓库 ID
wlt stock warehouse simple-list
# 查询该仓库库存
wlt stock query list --warehouse-id <ID>
```

### 2. 创建入库单

```bash
# 获取仓库列表（用于选择仓库）
wlt stock warehouse simple-list
# 创建入库单
wlt stock in create --data '{"warehouseId":1,"items":[{"productId":1,"count":10}]}'
```

### 3. 审核出入库单

```bash
# 查询待审核单据
wlt stock in list --status 0
# 审核通过
wlt stock in update-status --data '{"id":1,"status":2}'
```

## 错误处理

所有错误以 JSON 格式输出到 stderr，包含 type、code、message、hint 字段。

| 退出码 | type | 含义 | 处理方式 |
|--------|------|------|---------|
| 0 | — | 成功 | — |
| 1 | `general` | 通用错误 | 检查错误信息 |
| 2 | `config` | 配置错误 | 运行 `wlt config init` |
| 3 | `authentication` | 认证错误 | 运行 `wlt auth login` |
| 4 | `validation` | 参数错误 | 检查命令参数 |
| 5 | `api_error` | API 错误 | 使用 `--dry-run` 调试 |
| 6 | `network` | 网络错误 | 检查网络连接 |

## 注意事项

- 所有命令默认输出 JSON 格式到 stdout，进度/警告/错误输出到 stderr
- 删除操作接受多个 ID（逗号分隔）
- 分页默认 `page_no=1`, `page_size=20`
- 状态更新需遵循业务流转规则（如：未审核→已审核→已拒绝）
- 使用 `--profile prod` 切换到生产环境
- 使用 `--quiet` 静默模式，只输出数据
