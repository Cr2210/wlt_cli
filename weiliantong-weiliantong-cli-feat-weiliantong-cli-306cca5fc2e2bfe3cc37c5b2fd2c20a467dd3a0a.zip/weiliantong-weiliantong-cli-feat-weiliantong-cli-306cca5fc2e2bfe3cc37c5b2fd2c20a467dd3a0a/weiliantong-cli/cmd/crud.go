package cmd

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/cobra"

	"github.com/weiliantong/cli/internal/output"
)

// FlagSpec defines a filter flag for list commands.
type FlagSpec struct {
	Name  string // kebab-case flag name (e.g. "status", "category-id")
	Usage string // help text
}

// CRUDConfig configures a standard CRUD command group.
type CRUDConfig struct {
	Name         string     // subcommand name (empty = add directly to parent)
	APIPath      string     // base API path (e.g. "/erp/product")
	Label        string     // Chinese label (e.g. "产品")
	ListFilters  []FlagSpec // filter flags for list command
	SingleDelete bool       // true: delete with ?id=; false: delete with ?ids=
	SkipStatus   bool       // true: omit update-status subcommand
}

// newCRUDGroup creates a named sub-command with standard CRUD operations.
func newCRUDGroup(cfg CRUDConfig) *cobra.Command {
	parent := &cobra.Command{
		Use:   cfg.Name,
		Short: fmt.Sprintf("%s管理", cfg.Label),
	}
	addCRUDToParent(parent, cfg)
	return parent
}

// addCRUDToParent adds CRUD subcommands directly to a parent command.
func addCRUDToParent(parent *cobra.Command, cfg CRUDConfig) {
	parent.AddCommand(
		crudListCmd(cfg.APIPath, cfg.Label, cfg.ListFilters),
		crudGetCmd(cfg.APIPath, cfg.Label),
		crudCreateCmd(cfg.APIPath, cfg.Label),
		crudUpdateCmd(cfg.APIPath, cfg.Label),
		crudDeleteCmd(cfg.APIPath, cfg.Label, cfg.SingleDelete),
	)
	if !cfg.SkipStatus {
		parent.AddCommand(crudUpdateStatusCmd(cfg.APIPath, cfg.Label))
	}
}

// ---- Paginated list ----

func crudListCmd(apiPath, label string, filters []FlagSpec) *cobra.Command {
	var pageNo, pageSize int
	c := &cobra.Command{
		Use:   "list",
		Short: fmt.Sprintf("分页查询%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{
				"pageNo":   pageNo,
				"pageSize": pageSize,
			}
			for _, f := range filters {
				collectStringFlag(cmd, params, f.Name)
			}
			resp, err := apiClient.Get(context.Background(), apiPath+"/page", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("查询%s失败: %s", label, err), "")
			}
			return parsePagedJSON(resp.Data, pageNo, pageSize)
		},
	}
	c.Flags().IntVar(&pageNo, "page-no", 1, "页码")
	c.Flags().IntVar(&pageSize, "page-size", 20, "每页数量")
	for _, f := range filters {
		c.Flags().String(f.Name, "", f.Usage)
	}
	return c
}

// ---- Get by ID ----

func crudGetCmd(apiPath, label string) *cobra.Command {
	var id int64
	c := &cobra.Command{
		Use:   "get",
		Short: fmt.Sprintf("获取%s详情", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Get(context.Background(), apiPath+"/get", map[string]any{"id": id})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().Int64Var(&id, "id", 0, fmt.Sprintf("%s ID", label))
	_ = c.MarkFlagRequired("id")
	return c
}

// ---- Create ----

func crudCreateCmd(apiPath, label string) *cobra.Command {
	var data string
	c := &cobra.Command{
		Use:   "create",
		Short: fmt.Sprintf("创建%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "data 应为 JSON 对象")
			}
			resp, err := apiClient.Post(context.Background(), apiPath+"/create", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("创建%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据")
	_ = c.MarkFlagRequired("data")
	return c
}

// ---- Update ----

func crudUpdateCmd(apiPath, label string) *cobra.Command {
	var data string
	c := &cobra.Command{
		Use:   "update",
		Short: fmt.Sprintf("更新%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "data 应为 JSON 对象")
			}
			resp, err := apiClient.Put(context.Background(), apiPath+"/update", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("更新%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据")
	_ = c.MarkFlagRequired("data")
	return c
}

// ---- Delete ----

func crudDeleteCmd(apiPath, label string, single bool) *cobra.Command {
	if single {
		var id int64
		c := &cobra.Command{
			Use:   "delete",
			Short: fmt.Sprintf("删除%s", label),
			RunE: func(cmd *cobra.Command, args []string) error {
				if err := ensureClient(); err != nil {
					return err
				}
				resp, err := apiClient.Delete(context.Background(), apiPath+"/delete", map[string]any{"id": id})
				if err != nil {
					return output.NewExitError(5, fmt.Sprintf("删除%s失败: %s", label, err), "")
				}
				return outputJSON(json.RawMessage(resp.Data))
			},
		}
		c.Flags().Int64Var(&id, "id", 0, fmt.Sprintf("%s ID", label))
		_ = c.MarkFlagRequired("id")
		return c
	}
	var ids string
	c := &cobra.Command{
		Use:   "delete",
		Short: fmt.Sprintf("删除%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Delete(context.Background(), apiPath+"/delete", map[string]any{"ids": ids})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("删除%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&ids, "ids", "", "ID 列表（逗号分隔）")
	_ = c.MarkFlagRequired("ids")
	return c
}

// ---- Update status ----

func crudUpdateStatusCmd(apiPath, label string) *cobra.Command {
	var data string
	c := &cobra.Command{
		Use:   "update-status",
		Short: fmt.Sprintf("更新%s状态", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "")
			}
			resp, err := apiClient.Put(context.Background(), apiPath+"/update-status", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("更新%s状态失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据（含 id 和 status）")
	_ = c.MarkFlagRequired("data")
	return c
}

// ---- Simple list (no params) ----

func crudSimpleListCmd(apiPath, label string) *cobra.Command {
	c := &cobra.Command{
		Use:   "simple-list",
		Short: fmt.Sprintf("获取%s精简列表", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Get(context.Background(), apiPath+"/simple-list", nil)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取%s列表失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	return c
}

// ---- Simple list with query params ----

func crudSimpleListCmdWithFlags(apiPath, label string, flags []FlagSpec) *cobra.Command {
	c := &cobra.Command{
		Use:   "simple-list",
		Short: fmt.Sprintf("获取%s精简列表", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{}
			for _, f := range flags {
				collectStringFlag(cmd, params, f.Name)
			}
			resp, err := apiClient.Get(context.Background(), apiPath+"/simple-list", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取%s列表失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	for _, f := range flags {
		c.Flags().String(f.Name, "", f.Usage)
	}
	return c
}

// ---- Page count ----

func crudPageCountCmd(apiPath, label string, filters []FlagSpec) *cobra.Command {
	c := &cobra.Command{
		Use:   "page-count",
		Short: fmt.Sprintf("统计%s数量", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{}
			for _, f := range filters {
				collectStringFlag(cmd, params, f.Name)
			}
			resp, err := apiClient.Get(context.Background(), apiPath+"/page-count", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("统计%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	for _, f := range filters {
		c.Flags().String(f.Name, "", f.Usage)
	}
	return c
}

// ---- Non-paginated list (uses /list endpoint) ----

func crudListAllCmd(apiPath, label string, filters []FlagSpec) *cobra.Command {
	c := &cobra.Command{
		Use:   "list",
		Short: fmt.Sprintf("查询所有%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{}
			for _, f := range filters {
				collectStringFlag(cmd, params, f.Name)
			}
			resp, err := apiClient.Get(context.Background(), apiPath+"/list", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("查询%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	for _, f := range filters {
		c.Flags().String(f.Name, "", f.Usage)
	}
	return c
}

// ---- Helpers ----

// collectStringFlag collects a non-empty string flag into params map.
func collectStringFlag(cmd *cobra.Command, params map[string]any, name string) {
	v, err := cmd.Flags().GetString(name)
	if err == nil && v != "" {
		params[name] = v
	}
}

// parsePagedJSON extracts paginated data from API response and outputs it.
func parsePagedJSON(data json.RawMessage, pageNo, pageSize int) error {
	var paged struct {
		List  json.RawMessage `json:"list"`
		Total int64           `json:"total"`
	}
	if err := json.Unmarshal(data, &paged); err != nil {
		return output.NewExitError(5, fmt.Sprintf("解析响应失败: %s", err), "")
	}
	var list any
	if err := json.Unmarshal(paged.List, &list); err != nil {
		list = []any{}
	}
	return outputPagedJSON(list, paged.Total, pageNo, pageSize)
}
