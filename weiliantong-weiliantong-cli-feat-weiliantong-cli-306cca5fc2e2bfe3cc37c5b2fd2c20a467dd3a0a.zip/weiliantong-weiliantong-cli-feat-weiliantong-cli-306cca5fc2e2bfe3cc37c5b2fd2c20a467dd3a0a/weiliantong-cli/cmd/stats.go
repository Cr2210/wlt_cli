package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/spf13/cobra"

	"github.com/weiliantong/cli/internal/output"
)

var statsCmd = &cobra.Command{
	Use:   "stats",
	Short: "数据总览",
	Long:  "数据总览模块：经营总览、采购分析、销售分析、财务分析、生产分析、库存分析。",
}

func init() {
	rootCmd.AddCommand(statsCmd)

	// 经营总览（复用 /erp/homepage/dashboard2）
	statsCmd.AddCommand(newStatsOverviewCmd())
	// 库存分析（复用 /erp/homepage/dashboard6）
	statsCmd.AddCommand(newStatsGetCmd("stock", "/erp/homepage", "库存分析", dashboard6Flags))
}

// ---- Shared stats helpers ----

// defaultMonthRange returns (startOfMonth, now) formatted as "2006-01-02 15:04:05".
func defaultMonthRange() (string, string) {
	now := time.Now()
	start := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, now.Location())
	return start.Format("2006-01-02 15:04:05"), now.Format("2006-01-02 15:04:05")
}

// collectTimeRangeFlags collects time range flags with defaults.
func collectTimeRangeFlags(cmd *cobra.Command, params map[string]any) {
	t, _ := cmd.Flags().GetString("type")
	if t == "" {
		t = "month"
	}
	params["type"] = t

	startTime, _ := cmd.Flags().GetString("start-time")
	endTime, _ := cmd.Flags().GetString("end-time")
	if startTime == "" || endTime == "" {
		defStart, defEnd := defaultMonthRange()
		if startTime == "" {
			startTime = defStart
		}
		if endTime == "" {
			endTime = defEnd
		}
	}
	params["startTime"] = startTime
	params["endTime"] = endTime

	sortBy, _ := cmd.Flags().GetString("sort-by")
	if sortBy == "" {
		sortBy = "amount"
	}
	params["sortBy"] = sortBy
}

// addStatsFlags adds common stats flags (type/start-time/end-time/sort-by) to a command.
func addStatsFlags(c *cobra.Command) {
	c.Flags().String("type", "month", "时间类型（day/month/year）")
	c.Flags().String("start-time", "", "开始时间，默认当月1号")
	c.Flags().String("end-time", "", "结束时间，默认当前时间")
	c.Flags().String("sort-by", "amount", "排序字段，默认 amount")
}

// newStatsGetCmd creates a GET subcommand for statistics endpoints.
func newStatsGetCmd(name, apiPath, label string, extraFlags []FlagSpec) *cobra.Command {
	c := &cobra.Command{
		Use:   name,
		Short: label,
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{}
			collectTimeRangeFlags(cmd, params)
			for _, f := range extraFlags {
				collectStringFlag(cmd, params, f.Name)
			}
			suffix := name
			if apiPath == "/erp/homepage" {
				suffix = "dashboard6"
			}
			resp, err := apiClient.Get(context.Background(), apiPath+"/"+suffix, params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	addStatsFlags(c)
	for _, f := range extraFlags {
		c.Flags().String(f.Name, "", f.Usage)
	}
	return c
}

// newStatsOverviewCmd creates the overview command (dashboard2).
// Endpoint: GET /erp/homepage/dashboard2?productId=&type=&startTime=
func newStatsOverviewCmd() *cobra.Command {
	c := &cobra.Command{
		Use:   "overview",
		Short: "经营总览",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{}
			collectTimeRangeFlags(cmd, params)
			collectStringFlag(cmd, params, "product-id")
			resp, err := apiClient.Get(context.Background(), "/erp/homepage/dashboard2", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取经营总览失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	addStatsFlags(c)
	c.Flags().String("product-id", "", "产品 ID")
	return c
}

// Extra flags for dashboard6 (stock analysis)
var dashboard6Flags = []FlagSpec{
	{Name: "product-id", Usage: "产品 ID"},
	{Name: "warehouse-id", Usage: "仓库 ID"},
}
