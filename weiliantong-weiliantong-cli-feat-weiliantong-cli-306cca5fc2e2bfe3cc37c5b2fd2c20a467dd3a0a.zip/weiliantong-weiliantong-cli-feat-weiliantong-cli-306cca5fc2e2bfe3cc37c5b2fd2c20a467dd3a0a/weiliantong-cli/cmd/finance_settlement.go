package cmd

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/cobra"

	"github.com/weiliantong/cli/internal/output"
)

func init() {
	financeCmd.AddCommand(financeSettlementCmd)
}

var financeSettlementCmd = &cobra.Command{
	Use:   "settlement",
	Short: "结算单管理",
}

func init() {
	financeSettlementCmd.AddCommand(
		newFinanceSettlementListCmd(),
		newFinanceSettlementGetCmd(),
		newFinanceSettlementCreateCmd(),
		newFinanceSettlementUpdateCmd(),
		newFinanceSettlementDeleteCmd(),
		newFinanceSettlementUpdateStatusCmd(),
		newFinanceSettlementSummaryCmd(),
		newFinanceSettlementExportExcelCmd(),
		newFinanceSettlementFinanceRecordCmd(),
	)
}

// ---- 分页查询 ----

func newFinanceSettlementListCmd() *cobra.Command {
	var pageNo, pageSize int
	var settlementNo, customerId, supplierId, status, accountId, reviewerId string

	c := &cobra.Command{
		Use:   "list",
		Short: "分页查询结算单",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{
				"pageNo":   pageNo,
				"pageSize": pageSize,
			}
			collectStringFlags(cmd, params, "settlement-no", "customer-id", "supplier-id", "status", "account-id", "reviewer-id")

			resp, err := apiClient.Get(context.Background(), "/erp/finance-settlement/page", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("查询结算单失败: %s", err), "")
			}
			return parsePagedJSON(resp.Data, pageNo, pageSize)
		},
	}
	c.Flags().IntVar(&pageNo, "page-no", 1, "页码")
	c.Flags().IntVar(&pageSize, "page-size", 20, "每页数量")
	c.Flags().StringVar(&settlementNo, "settlement-no", "", "结算单号")
	c.Flags().StringVar(&customerId, "customer-id", "", "客户 ID")
	c.Flags().StringVar(&supplierId, "supplier-id", "", "供应商 ID")
	c.Flags().StringVar(&status, "status", "", "状态")
	c.Flags().StringVar(&accountId, "account-id", "", "账户 ID")
	c.Flags().StringVar(&reviewerId, "reviewer-id", "", "审核人 ID")
	return c
}

// ---- 获取详情 ----

func newFinanceSettlementGetCmd() *cobra.Command {
	var id int64

	c := &cobra.Command{
		Use:   "get",
		Short: "获取结算单详情",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Get(context.Background(), "/erp/finance-settlement/get", map[string]any{"id": id})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取结算单失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().Int64Var(&id, "id", 0, "结算单 ID")
	_ = c.MarkFlagRequired("id")
	return c
}

// ---- 创建 ----

func newFinanceSettlementCreateCmd() *cobra.Command {
	var data string

	c := &cobra.Command{
		Use:   "create",
		Short: "创建结算单",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "data 应为 JSON 对象")
			}
			resp, err := apiClient.Post(context.Background(), "/erp/finance-settlement/create", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("创建结算单失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据")
	_ = c.MarkFlagRequired("data")
	return c
}

// ---- 更新 ----

func newFinanceSettlementUpdateCmd() *cobra.Command {
	var data string

	c := &cobra.Command{
		Use:   "update",
		Short: "更新结算单",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "data 应为 JSON 对象")
			}
			resp, err := apiClient.Put(context.Background(), "/erp/finance-settlement/update", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("更新结算单失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据")
	_ = c.MarkFlagRequired("data")
	return c
}

// ---- 删除 ----

func newFinanceSettlementDeleteCmd() *cobra.Command {
	var id int64

	c := &cobra.Command{
		Use:   "delete",
		Short: "删除结算单",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Delete(context.Background(), "/erp/finance-settlement/delete", map[string]any{"id": id})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("删除结算单失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().Int64Var(&id, "id", 0, "结算单 ID")
	_ = c.MarkFlagRequired("id")
	return c
}

// ---- 更新状态 ----

func newFinanceSettlementUpdateStatusCmd() *cobra.Command {
	var data string

	c := &cobra.Command{
		Use:   "update-status",
		Short: "更新结算单状态",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "data 应为 JSON 对象")
			}
			resp, err := apiClient.Put(context.Background(), "/erp/finance-settlement/update-status", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("更新结算单状态失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据（含 id 和 status）")
	_ = c.MarkFlagRequired("data")
	return c
}

// ---- 汇总数据 ----

func newFinanceSettlementSummaryCmd() *cobra.Command {
	c := &cobra.Command{
		Use:   "summary",
		Short: "获取结算单汇总数据",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Get(context.Background(), "/erp/finance-settlement/summary", nil)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取结算单汇总失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	return c
}

// ---- 导出 Excel ----

func newFinanceSettlementExportExcelCmd() *cobra.Command {
	var settlementNo, customerId, supplierId, status, accountId, reviewerId string

	c := &cobra.Command{
		Use:   "export",
		Short: "导出结算单 Excel",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{}
			collectStringFlags(cmd, params, "settlement-no", "customer-id", "supplier-id", "status", "account-id", "reviewer-id")

			resp, err := apiClient.Get(context.Background(), "/erp/finance-settlement/export-excel", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("导出结算单失败: %s", err), "")
			}
			fmt.Println("导出成功，返回数据：", string(resp.Data))
			return nil
		},
	}
	c.Flags().StringVar(&settlementNo, "settlement-no", "", "结算单号")
	c.Flags().StringVar(&customerId, "customer-id", "", "客户 ID")
	c.Flags().StringVar(&supplierId, "supplier-id", "", "供应商 ID")
	c.Flags().StringVar(&status, "status", "", "状态")
	c.Flags().StringVar(&accountId, "account-id", "", "账户 ID")
	c.Flags().StringVar(&reviewerId, "reviewer-id", "", "审核人 ID")
	return c
}

// ---- 财务记录 ----

func newFinanceSettlementFinanceRecordCmd() *cobra.Command {
	var id int64

	c := &cobra.Command{
		Use:   "finance-record",
		Short: "获取结算单的财务记录",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Get(context.Background(), "/erp/finance-settlement/finance-record", map[string]any{"id": id})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取财务记录失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().Int64Var(&id, "id", 0, "结算单 ID")
	_ = c.MarkFlagRequired("id")
	return c
}
