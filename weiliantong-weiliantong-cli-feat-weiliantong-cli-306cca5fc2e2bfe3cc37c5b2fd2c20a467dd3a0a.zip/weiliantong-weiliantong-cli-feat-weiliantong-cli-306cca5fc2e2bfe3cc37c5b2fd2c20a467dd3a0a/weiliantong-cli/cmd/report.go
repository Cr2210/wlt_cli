package cmd

import "github.com/spf13/cobra"

var reportCmd = &cobra.Command{
	Use:   "report",
	Short: "报表管理",
	Long:  "报表模块操作：采购报表、销售报表、库存报表。",
}

func init() {
	rootCmd.AddCommand(reportCmd)
}
