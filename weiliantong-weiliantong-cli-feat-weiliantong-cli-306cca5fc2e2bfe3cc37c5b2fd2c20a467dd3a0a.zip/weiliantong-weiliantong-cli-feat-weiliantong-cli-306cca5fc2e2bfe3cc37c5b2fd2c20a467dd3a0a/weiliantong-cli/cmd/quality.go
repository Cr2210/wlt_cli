package cmd

import "github.com/spf13/cobra"

var qualityCmd = &cobra.Command{
	Use:   "quality",
	Short: "质检管理",
	Long:  "质检模块操作：质检单CRUD、质检称重。",
}

func init() {
	rootCmd.AddCommand(qualityCmd)
}
