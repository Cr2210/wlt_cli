package cmd

import (
	"context"
	"fmt"

	"github.com/spf13/cobra"

	"github.com/weiliantong/cli/internal/output"
)

var purchaseReportFilters = []FlagSpec{
	{Name: "supplier-id", Usage: "供应商 ID"},
	{Name: "product-id", Usage: "产品 ID"},
	{Name: "category-id", Usage: "分类 ID"},
	{Name: "warehouse-id", Usage: "仓库 ID"},
	{Name: "status", Usage: "状态"},
	{Name: "start-time", Usage: "开始时间"},
	{Name: "end-time", Usage: "结束时间"},
}

func init() {
	purchaseReportCmd := &cobra.Command{
		Use:   "purchase",
		Short: "采购报表管理",
	}
	purchaseReportCmd.AddCommand(
		newPurchaseReportDetailCmd(),
		newPurchaseReportSummerCmd(),
	)
	reportCmd.AddCommand(purchaseReportCmd)
}

// detail-page command
func newPurchaseReportDetailCmd() *cobra.Command {
	var pageNo, pageSize int
	c := &cobra.Command{
		Use:   "detail",
		Short: "采购报表明细查询",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{
				"pageNo":   pageNo,
				"pageSize": pageSize,
			}
			for _, f := range purchaseReportFilters {
				collectStringFlag(cmd, params, f.Name)
			}
			resp, err := apiClient.Get(context.Background(), "/erp/purchase-report/detail-page", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("查询采购报表明细失败: %s", err), "")
			}
			return parsePagedJSON(resp.Data, pageNo, pageSize)
		},
	}
	c.Flags().IntVar(&pageNo, "page-no", 1, "页码")
	c.Flags().IntVar(&pageSize, "page-size", 20, "每页数量")
	for _, f := range purchaseReportFilters {
		c.Flags().String(f.Name, "", f.Usage)
	}
	return c
}

// summer-page command
func newPurchaseReportSummerCmd() *cobra.Command {
	var pageNo, pageSize int
	c := &cobra.Command{
		Use:   "summer",
		Short: "采购报表汇总查询",
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{
				"pageNo":   pageNo,
				"pageSize": pageSize,
			}
			for _, f := range purchaseReportFilters {
				collectStringFlag(cmd, params, f.Name)
			}
			resp, err := apiClient.Get(context.Background(), "/erp/purchase-report/summer-page", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("查询采购报表汇总失败: %s", err), "")
			}
			return parsePagedJSON(resp.Data, pageNo, pageSize)
		},
	}
	c.Flags().IntVar(&pageNo, "page-no", 1, "页码")
	c.Flags().IntVar(&pageSize, "page-size", 20, "每页数量")
	for _, f := range purchaseReportFilters {
		c.Flags().String(f.Name, "", f.Usage)
	}
	return c
}
