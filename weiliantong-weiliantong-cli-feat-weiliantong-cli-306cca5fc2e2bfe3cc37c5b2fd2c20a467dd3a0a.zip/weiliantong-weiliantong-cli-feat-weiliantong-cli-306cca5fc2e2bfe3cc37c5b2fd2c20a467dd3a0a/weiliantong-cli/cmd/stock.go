package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/spf13/cobra"

	"github.com/weiliantong/cli/internal/output"
)

var stockCmd = &cobra.Command{
	Use:   "stock",
	Short: "库存管理",
	Long:  "库存模块操作：仓库、查询、入库、出库、调拨、盘点、明细。",
}

func init() {
	rootCmd.AddCommand(stockCmd)
}

// ---- Shared CRUD helpers ----

// newCRUDSubCmd creates a parent command for a stock CRUD subdomain
// (in/out/move/check) with list/get/create/update/delete/update-status subcommands.
func newCRUDSubCmd(name, apiPath, label string) *cobra.Command {
	cmd := &cobra.Command{
		Use:   name,
		Short: fmt.Sprintf("%s管理", label),
	}
	cmd.AddCommand(
		newListCmd(name, apiPath, label),
		newGetCmd(name, apiPath, label),
		newCreateCmd(name, apiPath, label),
		newUpdateCmd(name, apiPath, label),
		newDeleteCmd(name, apiPath, label),
		newUpdateStatusCmd(name, apiPath, label),
	)
	return cmd
}

// newListCmd creates a "list" subcommand for paginated queries.
func newListCmd(name, apiPath, label string) *cobra.Command {
	var pageNo, pageSize int
	c := &cobra.Command{
		Use:   "list",
		Short: fmt.Sprintf("分页查询%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			// Collect all non-empty flags as query params
			params := map[string]any{
				"pageNo":   pageNo,
				"pageSize": pageSize,
			}
			collectStringFlags(cmd, params, "warehouse-id", "product-id", "no", "status",
				"start-time", "end-time", "type")

			resp, err := apiClient.Get(context.Background(), apiPath+"/page", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("查询%s失败: %s", label, err), "使用 --dry-run 调试")
			}
			// Parse paginated data
			var paged struct {
				List  json.RawMessage `json:"list"`
				Total int64           `json:"total"`
			}
			if err := json.Unmarshal(resp.Data, &paged); err != nil {
				return output.NewExitError(5, fmt.Sprintf("解析响应失败: %s", err), "")
			}
			var list any
			if err := json.Unmarshal(paged.List, &list); err != nil {
				list = []any{}
			}
			return outputPagedJSON(list, paged.Total, pageNo, pageSize)
		},
	}
	c.Flags().IntVar(&pageNo, "page-no", 1, "页码")
	c.Flags().IntVar(&pageSize, "page-size", 20, "每页数量")
	addOptionalFlags(c)
	return c
}

// newGetCmd creates a "get" subcommand for fetching a single record.
func newGetCmd(name, apiPath, label string) *cobra.Command {
	var id int64
	c := &cobra.Command{
		Use:   "get",
		Short: fmt.Sprintf("获取%s详情", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Get(context.Background(), apiPath+"/get", map[string]any{"id": id})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().Int64Var(&id, "id", 0, fmt.Sprintf("%s ID", label))
	_ = c.MarkFlagRequired("id")
	return c
}

// newCreateCmd creates a "create" subcommand.
func newCreateCmd(name, apiPath, label string) *cobra.Command {
	var data string
	c := &cobra.Command{
		Use:   "create",
		Short: fmt.Sprintf("创建%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "data 应为 JSON 对象")
			}
			resp, err := apiClient.Post(context.Background(), apiPath+"/create", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("创建%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据")
	_ = c.MarkFlagRequired("data")
	return c
}

// newUpdateCmd creates an "update" subcommand.
func newUpdateCmd(name, apiPath, label string) *cobra.Command {
	var data string
	c := &cobra.Command{
		Use:   "update",
		Short: fmt.Sprintf("更新%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "data 应为 JSON 对象")
			}
			resp, err := apiClient.Put(context.Background(), apiPath+"/update", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("更新%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据")
	_ = c.MarkFlagRequired("data")
	return c
}

// newDeleteCmd creates a "delete" subcommand.
func newDeleteCmd(name, apiPath, label string) *cobra.Command {
	var ids string
	c := &cobra.Command{
		Use:   "delete",
		Short: fmt.Sprintf("删除%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Delete(context.Background(), apiPath+"/delete", map[string]any{"ids": ids})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("删除%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&ids, "ids", "", "ID 列表（逗号分隔）")
	_ = c.MarkFlagRequired("ids")
	return c
}

// newUpdateStatusCmd creates an "update-status" subcommand.
func newUpdateStatusCmd(name, apiPath, label string) *cobra.Command {
	var data string
	c := &cobra.Command{
		Use:   "update-status",
		Short: fmt.Sprintf("更新%s状态", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			body, err := parseJSONData(data)
			if err != nil {
				return output.NewExitError(4, fmt.Sprintf("解析 data 失败: %s", err), "data 应为 JSON 对象")
			}
			resp, err := apiClient.Put(context.Background(), apiPath+"/update-status", body)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("更新%s状态失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&data, "data", "", "JSON 数据（含 id 和 status）")
	_ = c.MarkFlagRequired("data")
	return c
}

// ---- Shared flag helpers ----

// addOptionalFlags adds common optional filter flags to a list command.
func addOptionalFlags(cmd *cobra.Command) {
	cmd.Flags().String("warehouse-id", "", "仓库 ID")
	cmd.Flags().String("product-id", "", "产品 ID")
	cmd.Flags().String("no", "", "单号")
	cmd.Flags().String("status", "", "状态")
	cmd.Flags().String("start-time", "", "开始时间")
	cmd.Flags().String("end-time", "", "结束时间")
	cmd.Flags().String("type", "", "类型")
}

// collectStringFlags collects non-empty string flags into params map.
func collectStringFlags(cmd *cobra.Command, params map[string]any, names ...string) {
	for _, name := range names {
		v, err := cmd.Flags().GetString(name)
		if err == nil && v != "" {
			params[name] = v
		}
	}
}

// collectIntFlags collects non-zero int flags into params map.
func collectIntFlags(cmd *cobra.Command, params map[string]any, names ...string) {
	for _, name := range names {
		v, err := cmd.Flags().GetInt64(name)
		if err == nil && v != 0 {
			params[name] = strconv.FormatInt(v, 10)
		}
	}
}
