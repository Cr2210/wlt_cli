package cmd

func init() {
	stockCmd.AddCommand(newCRUDSubCmd("move", "/erp/stock-move", "调拨单"))
}
