package cmd

import "github.com/spf13/cobra"

func init() {
	produceStats := &cobra.Command{
		Use:   "produce",
		Short: "生产分析",
	}
	produceStats.AddCommand(
		newStatsGetCmd("data-overview", "/erp/produce-statistics", "生产数据总览", nil),
	)
	statsCmd.AddCommand(produceStats)
}
