package cmd

import "github.com/spf13/cobra"

var contractCmd = &cobra.Command{
	Use:   "contract",
	Short: "合同管理",
	Long:  "合同模块操作：长协合同、供货合同、业务合同、运输合同。",
}

func init() {
	rootCmd.AddCommand(contractCmd)
}
