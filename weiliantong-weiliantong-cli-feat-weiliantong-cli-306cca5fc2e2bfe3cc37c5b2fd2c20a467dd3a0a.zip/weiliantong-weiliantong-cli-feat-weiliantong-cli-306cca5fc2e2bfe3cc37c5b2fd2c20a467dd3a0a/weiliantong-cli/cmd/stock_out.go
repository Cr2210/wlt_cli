package cmd

func init() {
	stockCmd.AddCommand(newCRUDSubCmd("out", "/erp/stock-out", "出库单"))
}
