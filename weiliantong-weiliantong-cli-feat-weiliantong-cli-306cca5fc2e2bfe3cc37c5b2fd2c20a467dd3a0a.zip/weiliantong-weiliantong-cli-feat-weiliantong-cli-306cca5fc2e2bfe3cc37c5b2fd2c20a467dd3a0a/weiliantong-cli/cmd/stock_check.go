package cmd

func init() {
	stockCmd.AddCommand(newCRUDSubCmd("check", "/erp/stock-check", "盘点单"))
}
