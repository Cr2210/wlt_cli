package cmd

import "github.com/spf13/cobra"

var customerCmd = &cobra.Command{
	Use:   "customer",
	Short: "客户管理",
	Long:  "客户模块操作：客户信息、开票信息、结算信息、授信管理。",
}

func init() {
	rootCmd.AddCommand(customerCmd)
	addPartnerCommands(customerCmd, "1", "客户")
	customerCmd.AddCommand(newInvoiceGroup())
	customerCmd.AddCommand(newSettlementGroup())
	customerCmd.AddCommand(newCreditGroup())
}
