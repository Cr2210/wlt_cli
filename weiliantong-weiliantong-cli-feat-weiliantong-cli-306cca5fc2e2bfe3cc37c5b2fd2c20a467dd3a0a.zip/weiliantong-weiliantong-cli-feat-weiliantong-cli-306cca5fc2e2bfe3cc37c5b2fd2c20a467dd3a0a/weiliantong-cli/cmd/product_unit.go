package cmd

func init() {
	unitCmd := newCRUDGroup(CRUDConfig{
		Name:    "unit",
		APIPath: "/erp/product-unit",
		Label:   "产品单位",
		ListFilters: []FlagSpec{
			{Name: "name", Usage: "单位名称"},
			{Name: "status", Usage: "状态"},
		},
		SingleDelete: true,
	})
	unitCmd.AddCommand(crudSimpleListCmd("/erp/product-unit", "产品单位"))
	productCmd.AddCommand(unitCmd)
}
