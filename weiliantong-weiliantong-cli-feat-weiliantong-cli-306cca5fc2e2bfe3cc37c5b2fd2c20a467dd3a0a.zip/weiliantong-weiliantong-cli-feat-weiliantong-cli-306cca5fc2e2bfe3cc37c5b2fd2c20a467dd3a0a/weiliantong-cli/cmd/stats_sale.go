package cmd

import "github.com/spf13/cobra"

func init() {
	saleStats := &cobra.Command{
		Use:   "sale",
		Short: "销售分析",
	}
	saleStats.AddCommand(
		newStatsGetCmd("data-overview", "/erp/sale-statistics", "销售数据总览", nil),
		newStatsGetCmd("customer-rankings", "/erp/sale-statistics", "客户排行", nil),
		newStatsGetCmd("product-rankings", "/erp/sale-statistics", "产品排行", nil),
		newStatsGetCmd("employee-rankings", "/erp/sale-statistics", "员工排行", nil),
		newStatsGetCmd("region-rankings", "/erp/sale-statistics", "区域排行", nil),
	)
	statsCmd.AddCommand(saleStats)
}
