package cmd

import "github.com/spf13/cobra"

func init() {
	// Category uses /list (non-paginated) instead of /page, so compose manually
	categoryCmd := &cobra.Command{
		Use:   "category",
		Short: "产品分类管理",
	}
	categoryCmd.AddCommand(
		crudListAllCmd("/erp/product-category", "产品分类", []FlagSpec{
			{Name: "name", Usage: "分类名称"},
			{Name: "status", Usage: "状态"},
			{Name: "parent-id", Usage: "父分类 ID"},
		}),
		crudGetCmd("/erp/product-category", "产品分类"),
		crudCreateCmd("/erp/product-category", "产品分类"),
		crudUpdateCmd("/erp/product-category", "产品分类"),
		crudDeleteCmd("/erp/product-category", "产品分类", true),
		crudUpdateStatusCmd("/erp/product-category", "产品分类"),
		crudSimpleListCmd("/erp/product-category", "产品分类"),
	)
	productCmd.AddCommand(categoryCmd)
}
