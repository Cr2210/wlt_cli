package cmd

func init() {
	purchaseCmd.AddCommand(newCRUDSubCmd("in", "/erp/purchase-in", "采购入库"))
}
