package cmd

func init() {
	purchaseCmd.AddCommand(newCRUDSubCmd("return", "/erp/purchase-return", "采购退货"))
}
