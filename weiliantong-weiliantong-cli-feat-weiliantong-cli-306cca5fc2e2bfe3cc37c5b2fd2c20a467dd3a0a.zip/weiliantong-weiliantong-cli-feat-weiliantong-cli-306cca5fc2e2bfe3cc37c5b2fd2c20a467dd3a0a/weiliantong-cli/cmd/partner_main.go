package cmd

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/spf13/cobra"

	"github.com/weiliantong/cli/internal/output"
)

// addPartnerCommands adds partner CRUD + extra commands to a parent,
// with the given type baked into list/simple-list/page-count queries.
func addPartnerCommands(parent *cobra.Command, partnerType, label string) {
	parent.AddCommand(
		newPartnerListCmd(partnerType, label),
		crudGetCmd("/erp/business-partner", label),
		crudCreateCmd("/erp/business-partner", label),
		crudUpdateCmd("/erp/business-partner", label),
		crudDeleteCmd("/erp/business-partner", label, true),
		crudUpdateStatusCmd("/erp/business-partner", label),
		newPartnerSimpleListCmd(partnerType, label),
		newPartnerPageCountCmd(partnerType, label),
		newPartnerUpdateAuditStatusCmd(label),
		newPartnerDeleteListCmd(label),
	)
}

func newPartnerListCmd(partnerType, label string) *cobra.Command {
	var pageNo, pageSize int
	c := &cobra.Command{
		Use:   "list",
		Short: fmt.Sprintf("分页查询%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{
				"pageNo":   pageNo,
				"pageSize": pageSize,
				"type":     partnerType,
			}
			collectStringFlag(cmd, params, "name")
			collectStringFlag(cmd, params, "status")
			collectStringFlag(cmd, params, "category-id")
			resp, err := apiClient.Get(context.Background(), "/erp/business-partner/page", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("查询%s失败: %s", label, err), "")
			}
			return parsePagedJSON(resp.Data, pageNo, pageSize)
		},
	}
	c.Flags().IntVar(&pageNo, "page-no", 1, "页码")
	c.Flags().IntVar(&pageSize, "page-size", 20, "每页数量")
	c.Flags().String("name", "", "名称")
	c.Flags().String("status", "", "状态")
	c.Flags().String("category-id", "", "分类 ID")
	return c
}

func newPartnerSimpleListCmd(partnerType, label string) *cobra.Command {
	c := &cobra.Command{
		Use:   "simple-list",
		Short: fmt.Sprintf("获取%s精简列表", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Get(context.Background(), "/erp/business-partner/simple-list",
				map[string]any{"type": partnerType})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("获取%s列表失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	return c
}

func newPartnerPageCountCmd(partnerType, label string) *cobra.Command {
	c := &cobra.Command{
		Use:   "page-count",
		Short: fmt.Sprintf("统计%s数量", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			params := map[string]any{"type": partnerType}
			collectStringFlag(cmd, params, "name")
			collectStringFlag(cmd, params, "status")
			resp, err := apiClient.Get(context.Background(), "/erp/business-partner/page-count", params)
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("统计%s失败: %s", label, err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().String("name", "", "名称")
	c.Flags().String("status", "", "状态")
	return c
}

func newPartnerUpdateAuditStatusCmd(label string) *cobra.Command {
	var id int64
	var status int
	c := &cobra.Command{
		Use:   "update-audit-status",
		Short: fmt.Sprintf("更新%s审核状态", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.PutQuery(context.Background(), "/erp/business-partner/update-audit-status",
				map[string]any{"id": id, "status": status})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("更新审核状态失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().Int64Var(&id, "id", 0, fmt.Sprintf("%s ID", label))
	c.Flags().IntVar(&status, "status", 0, "审核状态")
	_ = c.MarkFlagRequired("id")
	_ = c.MarkFlagRequired("status")
	return c
}

func newPartnerDeleteListCmd(label string) *cobra.Command {
	var ids string
	c := &cobra.Command{
		Use:   "delete-list",
		Short: fmt.Sprintf("批量删除%s", label),
		RunE: func(cmd *cobra.Command, args []string) error {
			if err := ensureClient(); err != nil {
				return err
			}
			resp, err := apiClient.Delete(context.Background(), "/erp/business-partner/delete-list",
				map[string]any{"ids": ids})
			if err != nil {
				return output.NewExitError(5, fmt.Sprintf("批量删除失败: %s", err), "")
			}
			return outputJSON(json.RawMessage(resp.Data))
		},
	}
	c.Flags().StringVar(&ids, "ids", "", "ID 列表（逗号分隔）")
	_ = c.MarkFlagRequired("ids")
	return c
}
