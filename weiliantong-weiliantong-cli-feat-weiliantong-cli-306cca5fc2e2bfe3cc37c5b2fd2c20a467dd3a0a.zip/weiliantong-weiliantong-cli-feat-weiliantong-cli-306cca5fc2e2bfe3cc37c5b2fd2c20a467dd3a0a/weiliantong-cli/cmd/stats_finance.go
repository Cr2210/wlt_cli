package cmd

import "github.com/spf13/cobra"

func init() {
	financeStats := &cobra.Command{
		Use:   "finance",
		Short: "财务分析",
	}
	financeStats.AddCommand(
		newStatsGetCmd("data-overview", "/erp/finance-statistics", "财务数据总览", nil),
		newStatsGetCmd("receivable-rankings", "/erp/finance-statistics", "应收款排行", nil),
		newStatsGetCmd("overdue-receivable-rankings", "/erp/finance-statistics", "逾期应收排行", nil),
		newStatsGetCmd("payable-rankings", "/erp/finance-statistics", "应付款排行", nil),
		newStatsGetCmd("overdue-payable-rankings", "/erp/finance-statistics", "逾期应付排行", nil),
	)
	statsCmd.AddCommand(financeStats)
}
