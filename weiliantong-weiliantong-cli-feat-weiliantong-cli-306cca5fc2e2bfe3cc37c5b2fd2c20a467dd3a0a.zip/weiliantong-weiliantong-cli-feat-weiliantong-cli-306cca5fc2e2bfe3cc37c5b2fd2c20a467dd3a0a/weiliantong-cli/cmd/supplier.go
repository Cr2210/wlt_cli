package cmd

import "github.com/spf13/cobra"

var supplierCmd = &cobra.Command{
	Use:   "supplier",
	Short: "供应商管理",
	Long:  "供应商模块操作：供应商信息、开票信息、结算信息。",
}

func init() {
	rootCmd.AddCommand(supplierCmd)
	addPartnerCommands(supplierCmd, "2", "供应商")
	supplierCmd.AddCommand(newInvoiceGroup())
	supplierCmd.AddCommand(newSettlementGroup())
}
