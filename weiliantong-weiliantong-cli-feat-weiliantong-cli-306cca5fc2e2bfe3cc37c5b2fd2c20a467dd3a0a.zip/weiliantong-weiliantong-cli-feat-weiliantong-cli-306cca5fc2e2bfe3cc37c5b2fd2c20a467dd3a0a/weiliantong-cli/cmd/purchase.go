package cmd

import "github.com/spf13/cobra"

var purchaseCmd = &cobra.Command{
	Use:   "purchase",
	Short: "采购管理",
	Long:  "采购模块操作：采购入库、采购退货。",
}

func init() {
	rootCmd.AddCommand(purchaseCmd)
}
