package cmd

func init() {
	stockCmd.AddCommand(newCRUDSubCmd("in", "/erp/stock-in", "入库单"))
}
