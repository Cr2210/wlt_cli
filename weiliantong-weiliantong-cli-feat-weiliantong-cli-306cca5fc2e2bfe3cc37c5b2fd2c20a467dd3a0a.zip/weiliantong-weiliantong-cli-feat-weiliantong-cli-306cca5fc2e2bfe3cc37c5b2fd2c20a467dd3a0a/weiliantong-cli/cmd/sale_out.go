package cmd

func init() {
	saleCmd.AddCommand(newCRUDSubCmd("out", "/erp/sale-out", "销售出库"))
}
