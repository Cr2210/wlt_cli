package cmd

import "github.com/spf13/cobra"

func init() {
	purchaseStats := &cobra.Command{
		Use:   "purchase",
		Short: "采购分析",
	}
	purchaseStats.AddCommand(
		newStatsGetCmd("data-overview", "/erp/purchase-statistics", "采购数据总览", nil),
		newStatsGetCmd("supplier-rankings", "/erp/purchase-statistics", "供应商排行", nil),
		newStatsGetCmd("product-rankings", "/erp/purchase-statistics", "产品排行", nil),
		newStatsGetCmd("employee-rankings", "/erp/purchase-statistics", "员工排行", nil),
		newStatsGetCmd("region-rankings", "/erp/purchase-statistics", "区域排行", nil),
	)
	statsCmd.AddCommand(purchaseStats)
}
