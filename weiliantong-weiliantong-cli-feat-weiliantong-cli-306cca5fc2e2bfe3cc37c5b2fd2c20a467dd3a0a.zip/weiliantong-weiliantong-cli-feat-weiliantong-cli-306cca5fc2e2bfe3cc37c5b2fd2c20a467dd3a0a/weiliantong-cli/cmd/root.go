package cmd

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/spf13/cobra"

	"github.com/weiliantong/cli/internal/auth"
	"github.com/weiliantong/cli/internal/client"
	"github.com/weiliantong/cli/internal/config"
	"github.com/weiliantong/cli/internal/output"
)

var (
	cfgMgr    *config.Manager
	authMgr   *auth.Manager
	apiClient *client.Client
)

var rootCmd = &cobra.Command{
	Use:   "wlt",
	Short: "维链通 ERP 命令行工具",
	Long:  "weiliantong-cli (wlt) — 维链通 ERP 系统的命令行工具，AI Agent 原生设计。",
	SilenceUsage:  true,
	SilenceErrors: true,
	PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
		profileName, _ := cmd.Flags().GetString("profile")
		cfgMgr = config.NewManager()
		cfgMgr.SetProfileOverride(profileName)
		if err := cfgMgr.Load(); err != nil {
			return output.NewExitError(2, fmt.Sprintf("加载配置失败: %s", err), "运行 wlt config init 初始化配置")
		}
		return nil
	},
	RunE: func(cmd *cobra.Command, args []string) error {
		return cmd.Help()
	},
}

func Execute() error {
	err := rootCmd.Execute()
	if err != nil {
		// Structured error output
		var exitErr *output.ExitError
		if as, ok := err.(*output.ExitError); ok {
			exitErr = as
		} else {
			exitErr = &output.ExitError{
				Code:    1,
				Type:    "general",
				Message: err.Error(),
			}
		}
		_ = output.WriteError(os.Stderr, exitErr)
		os.Exit(exitErr.Code)
	}
	return nil
}

func init() {
	rootCmd.PersistentFlags().String("profile", "sit", "配置环境")
	rootCmd.PersistentFlags().Bool("quiet", false, "静默模式")
}

// ensureClient initializes auth manager and API client on demand.
// Commands that need API access should call this first.
func ensureClient() error {
	if apiClient != nil {
		return nil
	}
	if cfgMgr == nil {
		return fmt.Errorf("配置未加载")
	}
	profile, err := cfgMgr.ActiveProfile()
	if err != nil {
		return output.NewExitError(2, fmt.Sprintf("当前环境配置不存在: %s", err), "运行 wlt config init 初始化")
	}
	authMgr = auth.NewManager(cfgMgr)
	apiClient = client.NewClient(profile, authMgr)
	return nil
}

// outputJSON writes data as JSON to stdout.
func outputJSON(data any) error {
	return output.WriteJSON(os.Stdout, data)
}

// outputPagedJSON writes paginated data as JSON to stdout.
func outputPagedJSON(list any, total int64, pageNo, pageSize int) error {
	return output.WritePagedJSON(os.Stdout, list, total, pageNo, pageSize)
}

// outputRaw writes raw bytes to stdout.
func outputRaw(data []byte) {
	output.WriteRaw(os.Stdout, data)
}

// parseJSONData parses a JSON string argument.
func parseJSONData(s string) (map[string]any, error) {
	if s == "" {
		return nil, fmt.Errorf("empty JSON data")
	}
	var result map[string]any
	if err := json.Unmarshal([]byte(s), &result); err != nil {
		return nil, fmt.Errorf("invalid JSON: %w", err)
	}
	return result, nil
}
